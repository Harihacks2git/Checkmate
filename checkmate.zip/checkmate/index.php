<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Profile Login</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f4f8;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .container {
            background-color: #ffffff;
            border-radius: 8px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
            padding: 40px;
            width: 300px;
            text-align: center;
        }

        h2 {
            margin-top: 0;
            color: #333;
        }

        label {
            display: block;
            margin-bottom: 10px;
            text-align: left;
            color: #333;
            font-weight: bold;
        }

        input[type="text"] {
            width: calc(100% - 22px);
            padding: 10px;
            margin-bottom: 20px;
            border-radius: 6px;
            border: 1px solid #ccc;
        }
        .high {
            background-repeat: no-repeat;
            background-size: cover;
            height: 100vh;
            width: 100vw;
            background-image: url('gradient.jpg');
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .container {
            height: 400px;
            width: 300px;
            border-radius: 10px;
            background-color: transparent;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 20px;
        }
        form input {
            margin-bottom: 10px;
            padding: 6px;
            border-radius: 10px;
            background-color: grey;
            opacity: 0.2;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            width: calc(100% - 16px); /* Adjust width to fit padding */
        }
        button {
            padding: 10px;
            border: none;
            border-radius: 25px;
            cursor: pointer;
            background-color:rgba(0, 0, 0, 0.562);
            color: white;
            font-size: 1em;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: grey;
        }

       
        .in-container{
            padding:50px;
        }
        #signOutBtn {
            background-color: #007bff;
            color: #ffffff;
            padding: 12px 25px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 16px;
            display: none;
            transition: background-color 0.3s ease;
        }

        #signOutBtn:hover {
            background-color: #0056b3;
        }
        .buttonsubmit{
            margin-top: 20px;
           justify-content: center;
        }
    </style>
</head>
<body>
    <div class="high">
    <div class="container">
        <h2>Student Profile Login</h2>
        <div class="in-container">
        <form id="loginForm" action="login.php"  method = "POST" onsubmit="return validateLoginForm()">
            <div>
                <label for="rollNo">Roll Number:</label>
                <input type="text" id="rollNo" name="roll_no" required>
            </div>
            <div>
                <label for="password">Password:</label>
                <input type="password" id="department" name="password" required>
    </div>
    <div class="buttonsubmit">
            <button type="submit">Login</button>

            <button  type="button" onclick="location.href='signup.php'">Sign up</button>
            </div>
        </form>
    </div>
    </div>

    <script>
        // Function to generate random captcha text
        function validateLoginForm() {
            var rollNo = document.getElementById('roll_no').value;
            var password = document.getElementById('password').value;
            if (!rollNo.trim()) {
                alert("Roll number is required.");
                return false;
            }
            if (!password.trim()) {
                alert("Password is required.");
                return false;
            }
            return true;
        }
      

    </script>
    </div>
</body>
</html>

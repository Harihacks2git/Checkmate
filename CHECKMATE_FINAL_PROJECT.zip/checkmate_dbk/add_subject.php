<?php
session_start();
if (!isset($_SESSION['roll_no'])) {
    exit();
}

$roll_no = $_SESSION['roll_no'];
$subject_name = $_POST['subject_name'];
$total_contact_hours = $_POST['total_contact_hours'];

$conn = new mysqli('localhost', 'root', '', 'checkmate');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$table_name = $roll_no . "_" . $subject_name;

// Check if the table already exists
$sql = "SHOW TABLES LIKE '$table_name'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo "exists";
} else {
    // Create the new subject table
    $sql = "CREATE TABLE $table_name (
        id INT AUTO_INCREMENT PRIMARY KEY,
        doa DATE,
        no_of_hours_absent INT,
        type_of_class VARCHAR(1),
        total_contact_hours INT
    )";
    if ($conn->query($sql) === TRUE) {
        // Insert the total contact hours
        $sql = "INSERT INTO $table_name (doa, no_of_hours_absent, type_of_class, total_contact_hours) 
                VALUES (NULL, NULL, NULL, $total_contact_hours)";
        $conn->query($sql);
        echo "created";
    } else {
        echo "Error creating table: " . $conn->error;
    }
}

$conn->close();
?>

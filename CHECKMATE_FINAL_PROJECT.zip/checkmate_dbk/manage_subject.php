<?php
session_start();
if (!isset($_SESSION['roll_no'])) {
    header("Location: login.html");
    exit();
}

$roll_no = $_SESSION['roll_no'];
$subject_name = $_GET['subject'];
$table_name = $roll_no . "_" . $subject_name;

$conn = new mysqli('localhost', 'root', '', 'checkmate');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch total contact hours and total absent hours
$sql = "SELECT SUM(no_of_hours_absent) AS total_absent_hours, MAX(total_contact_hours) AS total_contact_hours FROM $table_name";
$result = $conn->query($sql);
$row = $result->fetch_assoc();
$total_absent_hours = $row['total_absent_hours'] ? $row['total_absent_hours'] : 0;
$total_contact_hours = $row['total_contact_hours'] ? $row['total_contact_hours'] : 0;

$attendance_percentage = 0;
if ($total_contact_hours > 0) {
    $attendance_percentage = (($total_contact_hours - $total_absent_hours) / $total_contact_hours) * 100;
}

$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Subject</title>
    <script>
        function updateAttendance() {
            var date = document.getElementById('date').value;
            var no_of_hours_absent = document.getElementById('no_of_hours_absent').value;
            var type_of_class = document.getElementById('type_of_class').value;

            var xhr = new XMLHttpRequest();
            xhr.open("POST", "update_attendance.php", true);
            xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
            xhr.onreadystatechange = function () {
                if (xhr.readyState == 4 && xhr.status == 200) {
                    alert("Attendance updated successfully");
                    location.reload();
                }
            };
            xhr.send("subject=<?php echo $subject_name; ?>&date=" + date + "&no_of_hours_absent=" + no_of_hours_absent + "&type_of_class=" + type_of_class);
        }

        function viewStats() {
            window.location.href = "view_stats.php?subject=<?php echo $subject_name; ?>";
        }

        function updateTotalContactHours() {
            var totalContactHours = prompt("Enter the new total contact hours:");
            if (totalContactHours) {
                var xhr = new XMLHttpRequest();
                xhr.open("POST", "update_total_contact_hours.php", true);
                xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
                xhr.onreadystatechange = function () {
                    if (xhr.readyState == 4 && xhr.status == 200) {
                        alert("Total contact hours updated successfully");
                        location.reload();
                    }
                };
                xhr.send("subject=<?php echo $subject_name; ?>&total_contact_hours=" + totalContactHours);
            }
        }
    </script>
</head>
<body>
    <h2>Manage Subject: <?php echo $subject_name; ?></h2>
    <p>Total Contact Hours: <?php echo $total_contact_hours; ?></p>
    <p>Total Absent Hours: <?php echo $total_absent_hours; ?></p>
    <p>Attendance Percentage: <?php echo $attendance_percentage; ?>%</p>
    <button onclick="updateTotalContactHours()">Update Total Contact Hours</button>
    <form onsubmit="updateAttendance(); return false;">
        Date: <input type="date" id="date" name="date"><br>
        No. of Hours Absent: <input type="number" id="no_of_hours_absent" name="no_of_hours_absent"><br>
        Type of Class: 
        <select id="type_of_class" name="type_of_class">
            <option value="T">T</option>
            <option value="L">L</option>
        </select><br>
        <input type="submit" value="Update Attendance">
    </form>
    <button onclick="viewStats()">View Stats</button>
</body>
</html>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $roll_no = $_POST['roll_no'];
    $password = $_POST['password'];

    // Database connection
    $conn = new mysqli('localhost', 'root', '', 'checkmate');
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Check if user exists and validate password
    $sql = "SELECT password FROM students WHERE roll_no = '$roll_no'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if (password_verify($password, $row['password'])) {
            $sql2 = "SELECT * FROM students WHERE roll_no = $roll_no";
            $result2 = $conn->query($sql2);
            $r2 = $result2->fetch_assoc();
            session_start();
            $_SESSION["roll_no "] = $r2["roll_no"];
            $_SESSION["username"] = $r2["name"];
            $_SESSION["department"] = $r2["department"];
            $_SESSION["semester"] = $r2["semester"];
            header("Location: dashboard.php");
            exit();
        } else {
            echo "Invalid roll number or password.";
        }
    } else {
        echo "No such roll no Try signing up";
    }

    $conn->close();
}

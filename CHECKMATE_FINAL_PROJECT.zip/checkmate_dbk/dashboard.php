<?php
session_start();
if (!isset($_SESSION['roll_no'])) {
    header("Location: login.html");
    exit();
}
$roll_no = $_SESSION['roll_no'];
$name = $_SESSION['name'];
?>

<!DOCTYPE html>
<html>
<head>
    <title>Dashboard</title>
    <script>
        function addSubject() {
            var subjectName = prompt("Enter the subject name:");
            if (subjectName) {
                var totalContactHours = prompt("Enter the total contact hours for " + subjectName + ":");
                if (totalContactHours) {
                    // Check if subject already exists
                    var xhr = new XMLHttpRequest();
                    xhr.open("POST", "add_subject.php", true);
                    xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
                    xhr.onreadystatechange = function () {
                        if (xhr.readyState == 4 && xhr.status == 200) {
                            var response = xhr.responseText;
                            if (response == "exists") {
                                alert("Subject already exists");
                            } else if (response == "created") {
                                var newButton = document.createElement("button");
                                newButton.innerHTML = subjectName;
                                newButton.onclick = function() { manageSubject(subjectName); };
                                document.getElementById("subjects").appendChild(newButton);
                            }
                        }
                    };
                    xhr.send("subject_name=" + subjectName + "&total_contact_hours=" + totalContactHours);
                }
            }
        }

        function manageSubject(subjectName) {
            window.location.href = "manage_subject.php?subject=" + subjectName;
        }

        function resetAllData() {
            if (confirm("Are you sure you want to reset all data?")) {
                window.location.href = "reset_data.php";
            }
        }
    </script>
</head>
<body>
    <h2>Welcome, <?php echo $name; ?></h2>
    <script>
        setTimeout(function() {
            document.getElementById('welcome-message').style.display = 'none';
        }, 5000);
    </script>
    <div id="welcome-message">
        <p>Welcome, <?php echo $name; ?>!</p>
    </div>
    <button onclick="addSubject()">Add Subject</button>
    <button onclick="resetAllData()">Reset All Data</button>
    <div id="subjects">
        <?php
        // Fetch and display subjects
        $conn = new mysqli('localhost', 'root', '', 'checkmate');
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }
        $sql = "SHOW TABLES LIKE '$roll_no\_%'";
        $result = $conn->query($sql);
        while ($row = $result->fetch_assoc()) {
            $table_name = $row["Tables_in_checkmate($roll_no\\_%)"];
            $subject_name = substr($table_name, strpos($table_name, '_') + 1);
            echo "<button onclick=\"manageSubject('$subject_name')\">$subject_name</button>";
        }
        $conn->close();
        ?>
    </div>
</body>
</html>

<?php
session_start();
if (!isset($_SESSION['roll_no'])) {
    exit();
}

$roll_no = $_SESSION['roll_no'];
$subject_name = $_POST['subject'];
$date = $_POST['date'];
$no_of_hours_absent = $_POST['no_of_hours_absent'];
$type_of_class = $_POST['type_of_class'];

$table_name = $roll_no . "_" . $subject_name;

$conn = new mysqli('localhost', 'root', '', 'checkmate');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if total_contact_hours column exists, if not add it
$sql = "SHOW COLUMNS FROM $table_name LIKE 'total_contact_hours'";
$result = $conn->query($sql);
if ($result->num_rows == 0) {
    $conn->query("ALTER TABLE $table_name ADD total_contact_hours INT");
    // Set total_contact_hours initially to 0
    $conn->query("UPDATE $table_name SET total_contact_hours = 0");
}

$sql = "INSERT INTO $table_name (date, no_of_hours_absent, type_of_class) VALUES ('$date', $no_of_hours_absent, '$type_of_class')";
if ($conn->query($sql) === TRUE) {
    // Update total_absent_hours
    $sql = "UPDATE $table_name SET total_contact_hours = total_contact_hours + 1 WHERE id = LAST_INSERT_ID()";
    $conn->query($sql);
    echo "Attendance updated successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>

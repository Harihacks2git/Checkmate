<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Set Password</title>
    <style>
        body {
            margin: 0;
            font-family: 'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif;
        }

        .high {
            background-repeat: no-repeat;
            background-size: cover;
            height: 100vh;
            width: 100vw;
            background-image: url('gradient.jpg');
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .main {
            height: auto;
            width: 300px;
            border-radius: 10px;
            background-color:transparent;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 20px;
            box-sizing: border-box;
        }

        .heading {
            text-align: center;
            font-size: 1.5em;
            color: #333;
            margin-bottom: 20px;
        }

        form {
            width: 100%;
            display: flex;
            flex-direction: column;
        }

        form input {
            margin-bottom: 10px;
            padding: 10px;
            border-radius: 5px;
            /* background-color: grey; */
            opacity: 0.4;
            border: 1px solid #ccc;
            width: calc(100% - 22px); Adjust width to fit padding and border
        }

        form input[type="submit"] {
            background-color: grey;
            border: none;
            border-radius: 50px;
            margin-left: 13px;
        }
        #password,#confirm_password{
            width: 130px;
        }

        button {
            padding: 10px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            color: white;
            width: auto;
            height: 40px;
            transition: background-color 0.3s ease;
            background-color: transparent;
        }

        button:hover {
            background-color: grey;
            opacity: 0.6;
        }
        .show{
            background-color: grey;
            border: none;
            border-radius: 100px;
            color: black;
            font-family: 'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif;
        }
        button.show{
            background-color: transparent;
        }
        .in-1{
            display: flex;
            flex-direction: row;
            justify-content: space-evenly;
            align-items: center;
        }
        .in-2{
            display: flex;
            flex-direction: row;
            justify-content: space-evenly;
            align-items: center;
        }
        
    </style>
    <script>
        function validatePasswordForm() {
            var password = document.getElementById('password').value;
            var confirmPassword = document.getElementById('confirm_password').value;
            var passwordPattern = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{6,}$/;

            if (!passwordPattern.test(password)) {
                alert("Password must be at least 6 characters long, contain at least one uppercase letter, one lowercase letter, and one number.");
                return false;
            }
            if (password !== confirmPassword) {
                alert("Passwords do not match.");
                return false;
            }

            return true;
        }

        function togglePasswordVisibility1() {
            var passwordInput = document.getElementById('password');
            if (passwordInput.type === "password") {
                passwordInput.type = "text";
            } else {
                passwordInput.type = "password";
            }
        }
        function togglePasswordVisibility2() {
            var passwordInput = document.getElementById('confirm_password');
            if (passwordInput.type === "password") {
                passwordInput.type = "text";
            } else {
                passwordInput.type = "password";
            }
        }
    </script>
</head>
<body>
    <div class="high">
        <div class="main">
            <h2 class="heading">Set Password</h2>
            <form action="set_password.php" method="post" onsubmit="return validatePasswordForm()"><div class="in-1">
                Password: <input type="password" id="password" name="password">
                <button type="button" onclick="togglePasswordVisibility1()" class="show">&#128065;</button></div><div class="in-2">
                Confirm: <input type="password" id="confirm_password" name="confirm_password">
                <button type="button" onclick="togglePasswordVisibility2()" class="show">&#128065;</button></div><br>
                <input type="submit" class="submit" value="Submit">
            </form>
        </div>
    </div>
</body>
</html>
